package jp.simple_asta.blog.b2.server;

import java.io.IOException;

import jp.simple_asta.blog.b2.client.GreetingService;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class GreetingServiceImpl extends RemoteServiceServlet implements
		GreetingService {

	public String greetServer(String input) throws IllegalArgumentException {
		input = escapeHtml(input);

		if (input.equals("CategoryList")) {
			String[][][] cl = B2.getCategoryList();
			StringBuilder sb = new StringBuilder();
			for (int i = 0, l = cl.length; i < l; i++) {
				sb.append(i).append(",").append(cl[i][0][0]);
				if (i + 1 < l) {
					sb.append(";");
				}
			}
			
//				ByteArrayOutputStream out = new ByteArrayOutputStream();
//				GZIPOutputStream gzout = new GZIPOutputStream(new BufferedOutputStream(out));
//				gzout.write(sb.toString().getBytes());
//				gzout.finish();
//				out.close();
//				gzout.close();
//				byte[] ziped = out.toByteArray();
				
	            return new String(Base64.byteArrayToBase64(sb.toString().getBytes()));
			
		} else if (input.startsWith("BoardList")) {
			String idstr = input.split(" ")[1];
			
			String[][][] cl = B2.getCategoryList();
			StringBuilder sb = new StringBuilder();
			int id = Integer.parseInt(idstr);
			for (int i = 0, l = cl[id].length; i < l; i++) {
				sb.append(i).append(",").append(cl[id][i][0]);
				if (i + 1 < l) {
					sb.append(";");
				}
			}
			return sb.toString();
		} else if (input.startsWith("ThreadList")) {
			String categoryidstr = input.split(" ")[1];
			String boardidstr = input.split(" ")[2];
			
			String[][][] cl = B2.getCategoryList();
			StringBuilder sb = new StringBuilder();
			int categoryid = Integer.parseInt(categoryidstr);
			int boardid = Integer.parseInt(boardidstr);
			String[][] threadlist = B2.getThreadList( cl[categoryid][boardid]);
			for (int i = 0, l = threadlist.length; i < l; i++) {
				
				sb.append(i).append("<>").append(escapeHtml(threadlist[i][0]));
				if (i + 1 < l) {
					sb.append("><");
				}
			}
			return sb.toString();
		} else {
			return "";
		}
		// + ".<br><br>It looks like you are using:<br>" + userAgent;
	}

	/**
	 * Escape an html string. Escaping data received from the client helps to
	 * prevent cross-site script vulnerabilities.
	 * 
	 * @param html
	 *            the html string to escape
	 * @return the escaped string
	 */
	private String escapeHtml(String html) {
		if (html == null) {
			return null;
		}
		return html.replaceAll("&", "&amp;").replaceAll("<", "&lt;")
				.replaceAll(">", "&gt;");
	}
}
